#Preheat Retreat
#Morgan Nalesnik
#10/21/2022
#asthma status




# Install libraries
# We will need need tidyverse, randomForest, janitor, and xgboost
# Remember you can pass a vector of library names to install multiple libraries at once
install.packages(c("tidyverse", "randomForest", "janitor", "xgboost", "nnet", "dplyr"))


# Load libraries
library(tidyverse)
library(randomForest)
library(janitor)
library(xgboost)
library(nnet)
library(slice)
library(dplyr)

...


# Load data

data_proteomics = read.csv("/cloud/project/3. Data Analysis/Data/Processed_Proteomics_Data.csv")
data_demo = read.csv("./3. Data Analysis/Data/Demographic_Data.csv")

# Change to tidy format 

data_tidy <-
  data_proteomics %>% 
  pivot_longer(cols=c(2:ncol(data_proteomics)), names_to = 'SampleID', values_to = 'Value') %>% 
  pivot_wider(names_from = 'Gene_Name', values_from='Value')


# Join the two dataframes on SampleID, preserving all the rows in proteomics (what kind of join is this? Type ?join in your console to see the documentation)
# Drop the SampleID column afterwards

data_predict <-
  data_tidy %>% 
  left_join(data_demo, by="SampleID") %>% 
  select(c(2:ncol(data_tidy), Asthma_Status)) %>% 
  clean_names()

# Note that clean_names might change the column name of your prediction value of interest 
# Make sure you take a look at your resulting dataframe to see the new colume name

# Build a linear model. Remember that if you are doing a binomial regression you will need to convert your outcome to a binary output
# Multinomial regression will use the multinom() function from nnet package

data_predict <-
  data_predict %>% 
  mutate(asthma_status = ifelse(asthma_status == 'NAS', 0, 1))

# Shuffle the data set and split into a test and prediction data

shuffle_idx = sample(nrow(data_predict), nrow(data_predict))
data_predict_shuffled <- data_predict[shuffle_idx,]

split_idx <- sample(c(T,F), size=nrow(data_predict), replace=T, prob=c(0.80, 0.20))
  #80 20 is a common split, you can test on other splits too

data_train <- data_predict_shuffled[split_idx,]
data_test <- data_predict_shuffled[!split_idx,]
#see that data_train has 80% of values and data_test has 20% of the values = the ! excluded the %80

mdl <- glm(asthma_status~., family=binomial, data = data_train)
#glm = generalize linear model, predicting on asthma status on all variable "."
#~ separated x and y
#family binomil = we are doing a logistic progression
#we are looking at just the training data

# Predict on your test data and plot accuracy

logit_pred <- predict(mdl, data_test %>% select(-asthma_status), type='response')

# Convert your coefficients into a dataframe so you can plot feature importances

 #we are making a dataframe out of just the coefficients
#coefficients are the slope of the log odds,
#this coefficient willl vary based on the regression = we are using a binomial regression
#the larger the coefficient (absolute value) the larger the influence of that gene/protein/etc.

# Hint: you will need to manipulate this dataframe, sort it, and take the first 10 rows to plot

# Next step, repeat but for a Random Forest classifier

mdl_coeff <- as.data.frame(coefficients(mdl)) %>% 
  abs(mdl_coeff) %>% #get the absolute value of the numeric data
  clean_names() %>% 
  mutate(gene = rownames(.)) %>% #we will add column called "gene" because now it is a row name and ggplot doesn't plot rownames
  arrange(desc(coefficients((mdl)))) %>% #arrange this data into descending order


#Slice and often the function slect is found within multiple packages
#sometimes R doesn't know which to choose from
#dplyr::slice tells R to use slice from the dplyr package

ggplot(mdl_coeff, aes(x=gene, y=coefficients(mdl)) + 
  geom_col()







rf <- randomForest(formula=??, data=??, importance=T)

rf_predict <- predict(??, ??)

rf_importances <- as.data.frame(importance(rf_model))

# Now you can plot feature importance after sorting and taking the top 10 features

# Lastly, use xgboost to do the same

xgb <- xgboost(data=??, label=??, nrounds=20)

xgb_predict(??, ??)

# Don't worry about feature importances for xgboost

